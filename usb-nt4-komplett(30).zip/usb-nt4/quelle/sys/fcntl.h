/*  Leerer Rumpf.  Gehoert zum Zeichengeraet /dev/ugen, das ueber
 *  USB_HAVE_UGEN = 0 abgeschaltet ist -- siehe dev/usb/usb_freebsd.h.  */
#ifndef _SYS_STUB_fcntl_
#define _SYS_STUB_fcntl_
#endif
